/** Typed wrappers around the Supabase Edge Functions (supabase/functions). The browser never writes to tables directly. */
import { supabase } from "../lib/supabase";
import { SLUG_MESSAGES } from "../lib/validation";
import { fail, ok, type Result } from "./result";

export interface StoreSummary {
  id: string;
  slug: string;
  name: string;
  category: string;
  city: string | null;
  state: string | null;
  is_published: boolean;
  status: "active" | "suspended";
}
/** The vendor's own store, including private fields. Only ever returned to its owner. */
export interface OwnStore {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string;
  category: string;
  city: string | null;
  state: string | null;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  og_image_url: string | null;
  logo_url: string | null;
  cover_url: string | null;
  storefront_layout?: "editorial" | "classic" | "minimal" | "showcase";
  hero_eyebrow?: string | null;
  hero_title?: string | null;
  hero_description?: string | null;
  hero_button_text?: string | null;
  category_heading?: string | null;
  products_heading?: string | null;
  promo_one_title?: string | null;
  promo_one_text?: string | null;
  promo_one_image_url?: string | null;
  promo_two_title?: string | null;
  promo_two_text?: string | null;
  promo_two_image_url?: string | null;
  facebook_url?: string | null;
  instagram_url?: string | null;
  tiktok_url?: string | null;
  youtube_url?: string | null;
  x_url?: string | null;
  threads_url?: string | null;
  snapchat_url?: string | null;
  pinterest_url?: string | null;
  linkedin_url?: string | null;
  other_social_label?: string | null;
  other_social_url?: string | null;
  indexable: boolean;
  contact_phone: string | null;
  contact_email: string | null;
  is_published: boolean;
  status: "active" | "suspended";
}
export interface SeoStatus {
  published: boolean;
  eligible: boolean;
  problems: string[];
  custom_title: boolean;
  custom_description: boolean;
  has_social_image: boolean;
  published_products: number;
  eligible_products: number;
}
export interface StoreSeoInput {
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string;
  og_image_url?: string;
  indexable?: boolean;
  category?: string;
  city?: string;
  state?: string;
  tagline?: string;
  description?: string;
  cover_url?: string;
  storefront_layout?: "editorial" | "classic" | "minimal" | "showcase";
  contact_phone?: string;
  hero_eyebrow?: string | null;
  hero_title?: string | null;
  hero_description?: string | null;
  hero_button_text?: string | null;
  category_heading?: string;
  products_heading?: string | null;
  promo_one_title?: string | null;
  promo_one_text?: string | null;
  promo_one_image_url?: string | null;
  promo_two_title?: string | null;
  promo_two_text?: string | null;
  promo_two_image_url?: string | null;
  facebook_url?: string;
  instagram_url?: string;
  tiktok_url?: string;
  youtube_url?: string;
  x_url?: string;
  threads_url?: string;
  snapchat_url?: string;
  pinterest_url?: string;
  linkedin_url?: string;
  other_social_label?: string;
  other_social_url?: string;
}

export interface SubscriptionSummary {
  plan_code: string;
  status: string;
  current_period_end: string;
  active: boolean;
}
export type NextStep = "create_store" | "subscribe" | "done";
export interface Me {
  user: { id: string; email: string | null };
  profile: { full_name: string; phone: string | null } | null;

  store: OwnStore | null;
  subscription: SubscriptionSummary | null;
  seo_status: SeoStatus | null;

  next_step: NextStep;
}
export interface StoreInput {
  name: string;
  slug: string;
  category: string;
  city?: string;
  state?: string;

  phone?: string;

}
export type PaymentStatus = "success" | "pending" | "failed";

const MESSAGES: Record<string, string> = {
  unauthorized: "Your session has expired. Please log in again.",
  admin_required: "This account does not have platform admin access.",
  invalid_admin_action: "Please check the admin action and its reason.",
  support_submit_failed: "We couldn't send your message. Please try again.",
  slug_taken: SLUG_MESSAGES.taken,
  store_exists: "You already have a store.",
  store_required: "Create your store first.",
  payment_provider_error: "We couldn't start the payment. Please try again.",
  payment_not_found: "We couldn't find that payment.",
  payment_mismatch: "That payment didn't match your plan. Please contact support.",
  invalid_input: "Please check the details you entered.",

  nothing_to_update: "There were no changes to save.",
  body_too_large: "That request was too large.",
  subscription_required: "Your subscription has ended, so you can view your records but not change them. Renew to continue.",
  store_suspended: "Your store is suspended. Please contact support.",
  insufficient_stock: "There isn't enough stock for one of these products.",
  product_not_found: "That product wasn't found in your catalogue.",
  product_unavailable: "One of the products is no longer available.",
  customer_not_found: "That customer wasn't found.",
  order_not_found: "That order wasn't found.",
  order_cancelled: "This order is cancelled.",
  order_paid: "This order is fully paid, so it has no invoice. Open its receipt instead.",
  invalid_template: "Something in the design isn't allowed. Check your colours and image links.",
  invalid_payment_details: "Please check the account details.",
  invalid_transition: "That status change isn't allowed.",
  overpayment: "That is more than the customer still owes.",
  invalid_payment: "Please check the payment details.",
  invalid_customer: "Please check the customer details.",
  invalid_item: "Please check the products and quantities.",
  no_items: "Add at least one product.",
  too_many_items: "A sale can have at most 50 lines.",
  too_many_orders: "Too many orders from this number. Please wait a while or contact the store.",
  store_not_found: "This store isn't available.",
};

export async function call<T>(name: string, body?: Record<string, unknown>): Promise<Result<T>> {

  if (!supabase) return fail("not_configured", "The service isn't connected yet. Please try again later.");
  const { data, error } = await supabase.functions.invoke<T>(name, { body });
  if (!error) return ok(data as T);

  let code = "request_failed";
  let detail = "";
  const response = (error as { context?: Response }).context;
  if (response && typeof response.json === "function") {
    try {
      const payload = (await response.json()) as { error?: string; message?: string };
      code = payload.error ?? code;
      detail = payload.message ?? "";
    } catch {
      /* not JSON: keep the generic message */
    }
  }
  const message =
    code === "invalid_slug"
      ? (SLUG_MESSAGES[detail] ?? SLUG_MESSAGES.invalid_characters)
      : (code === "invalid_template" || code === "invalid_payment_details") && detail
        ? detail
        : (MESSAGES[code] ?? "Something went wrong. Please try again.");
  return fail(code, message);
}

export const getMe = () => call<Me>("me");
export const checkSlug = (slug: string) =>
  call<{ slug: string; available: boolean; reason?: string }>("check-slug", { slug });
export const createStore = (input: StoreInput) => call<{ store: StoreSummary }>("create-store", { ...input });
export const startSubscription = () =>
  call<{ authorization_url: string; reference: string }>("subscription-initialize", {});

export const updateStoreSeo = (input: StoreSeoInput) =>
  call<{ store: OwnStore; seo_status: SeoStatus }>("update-store-seo", { ...input });

export const verifyPayment = (reference: string) =>
  call<{ status: PaymentStatus }>("subscription-verify", { reference });

export const adminCall = <T>(action: string, body: Record<string, unknown> = {}) =>
  call<T>("admin-console", { action, ...body });

export const submitSupportRequest = (input: {
  name: string; email: string; topic: string; message: string; phone?: string;
  request_type?: "general" | "store_report" | "vendor_complaint"; store_slug?: string;
}) =>
  call<{ request_id: string }>("support-request", input);
